﻿namespace CallAPI.Entities
{
    public class Events
    {
        public int Id { get; set; }
        public int Name { get; set; }
    }
}

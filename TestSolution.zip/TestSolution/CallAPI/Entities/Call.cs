﻿namespace CallAPI.Entities
{
    public class Call
    {
        public long CallId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string CallFrom { get; set; }
        public string CallTo { get; set; }

    }
}

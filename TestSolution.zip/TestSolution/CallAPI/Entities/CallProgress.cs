﻿namespace CallAPI.Entities
{
    public class CallProgress
    {
        public long CallId { get; set;}
        public int EventTypeId {get; set;}
        public DateTime EventTIme { get; set;}

    }
}

namespace CallAPI.Helpers;

public class DbSettings
{
    public string? Server { get; set; }
    public string? Database { get; set; }
    public string? UserId { get; set; }
    public string? Password { get; set; }

    //ConnectionString property keep if directly want to use connectionstring details instead passing individual property like server,login,password 
    public string? ConnectionString { get; set;}
}
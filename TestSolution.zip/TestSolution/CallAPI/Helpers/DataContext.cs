namespace CallAPI.Helpers;

using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

public class DataContext
{
    private DbSettings _dbSettings;

    public DataContext(IOptions<DbSettings> dbSettings)
    {
        _dbSettings = dbSettings.Value;
    }

    public IDbConnection CreateConnection()
    {
        string connectionString =string.Empty;
        if ((!string.IsNullOrEmpty(_dbSettings.ConnectionString) || !string.IsNullOrWhiteSpace(_dbSettings.ConnectionString)) && (string.IsNullOrEmpty(_dbSettings.UserId) || string.IsNullOrEmpty(_dbSettings.Password)))
        {
            connectionString = _dbSettings.ConnectionString;
        }
        else
        {
          connectionString = $"Server={_dbSettings.Server}; Database={_dbSettings.Database}; User Id={_dbSettings.UserId}; Password={_dbSettings.Password};";
        }
        return new SqlConnection(connectionString);
    }

    public string GetConnectionString()
    {
        string connectionString = string.Empty;
        if ((!string.IsNullOrEmpty(_dbSettings.ConnectionString) || !string.IsNullOrWhiteSpace(_dbSettings.ConnectionString)) && (string.IsNullOrEmpty(_dbSettings.UserId) || string.IsNullOrEmpty(_dbSettings.Password)))
        {
            connectionString = _dbSettings.ConnectionString;
        }
        else
        {
            connectionString = $"Server={_dbSettings.Server}; Database={_dbSettings.Database}; User Id={_dbSettings.UserId}; Password={_dbSettings.Password};";
        }
        return connectionString;
    }



    // use for buffered queries that return a type
    public async Task<T> WithConnection<T>(Func<IDbConnection, Task<T>> getData)
    {
        try
        {
           await using var connection = new SqlConnection(GetConnectionString());
            await connection.OpenAsync();
            return await getData(connection);
        }
        catch (TimeoutException ex)
        {
            throw new Exception(String.Format("{0}.WithConnection() experienced a SqlConnection timeout", GetType().FullName), ex);
        }
        catch (Exception ex)
        {
            throw new Exception(String.Format("{0}.WithConnection() experienced a SqlConnection exception (not a timeout)", GetType().FullName), ex);
        }
    }

    // use for buffered queries that do not return a type
    public async Task WithConnection(Func<IDbConnection, Task> getData)
    {
        try
        {
            await using var connection = new SqlConnection(GetConnectionString());
            await connection.OpenAsync();
            await getData(connection);
        }
        catch (TimeoutException ex)
        {
            throw new Exception(String.Format("{0}.WithConnection() experienced a SqlConnection timeout", GetType().FullName), ex);
        }
        catch (Exception ex)
        {
            throw new Exception(String.Format("{0}.WithConnection() experienced a SqlConnection exception (not a timeout)", GetType().FullName), ex);
        }
    }

    //use for non-buffered queries that return a type
    public async Task<TResult> WithConnection<TRead, TResult>(Func<IDbConnection, Task<TRead>> getData, Func<TRead, Task<TResult>> process)
    {
        try
        {
            await using var connection = new SqlConnection(GetConnectionString());
            await connection.OpenAsync();
            var data = await getData(connection);
            return await process(data);
        }
        catch (Exception ex)
        {
            throw;
        }

    }

}
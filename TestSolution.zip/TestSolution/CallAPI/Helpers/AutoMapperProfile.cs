namespace CallAPI.Helpers;

using AutoMapper;
using CallAPI.Entities;
using CallAPI.Models;

public class AutoMapperProfile : Profile
{
    public AutoMapperProfile()
    {
      
    }
}
﻿using AutoMapper;
using CallAPI.Models;
using CallAPI.Repositories;

namespace CallAPI.Services
{
    public class CallService : ICallService
    {
        private ICallRepository _callRepository;
        private readonly IMapper _mapper;

        public CallService(
            ICallRepository callRepository,
            IMapper mapper)
        {
            _callRepository = callRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<CallSummaryResponse>> GetCallSummaryReport(string? eventFromTime, string? eventToTime)
        {
            return await _callRepository.GetCallSummaryReport(eventFromTime, eventToTime);
        }

        public async Task<IEnumerable<MissedCallResponse>> GetMissedCallDetails(string callId, string eventFromTime, string eventToTime)
        {
            var call = await _callRepository.GetMissedCallDetails(callId,eventFromTime, eventToTime);

            if (call == null)
                throw new KeyNotFoundException("Call not found");

            return call;
        }
    }

    public interface ICallService
    {

        Task<IEnumerable<MissedCallResponse>> GetMissedCallDetails(string callId, string eventFromTime, string eventToTime);
        Task<IEnumerable<CallSummaryResponse>> GetCallSummaryReport(string? eventFromTime, string? eventToTime);

    }
}

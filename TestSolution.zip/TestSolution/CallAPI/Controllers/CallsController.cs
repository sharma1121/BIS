﻿using CallAPI.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CallAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CallsController : ControllerBase
    {
        private ICallService _callService;

        public CallsController(ICallService callService)
        {
            _callService = callService;
        }


        [HttpGet("MissedCall")]
        public async Task<IActionResult> GetMissCalledDetails([FromQuery] string callId,[FromQuery] string eventFromTime, [FromQuery] string eventToTime)
        {
            var missedCall = await _callService.GetMissedCallDetails(callId,eventFromTime, eventToTime);
            return Ok(missedCall);
        }

        [HttpGet("CallSummaryReport")]
        public async Task<IActionResult> CallSummaryReport([FromQuery] string? eventFromTime, [FromQuery] string? eventToTime)
        {
            var callSummary= await _callService.GetCallSummaryReport(eventFromTime,eventToTime);
            return Ok(callSummary);
        }
    }
}

﻿namespace CallAPI.Models
{
    public class CallSummaryResponse
    {
        public string Date { get; set; }
        public int CallRecieved { get; set; }
        public int CallAnswered { get; set; }
        public int CallMissed { get; set; }
        public string TotalTalkTime { get; set; }
        public string AverageTalkTime { get; set; }

    }
}

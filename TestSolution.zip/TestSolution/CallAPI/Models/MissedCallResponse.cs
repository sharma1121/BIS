﻿namespace CallAPI.Models
{
    public class MissedCallResponse
    {

        public string Date { get; set; }
        public string CalledFrom { get; set; }
        public string CalledTo { get; set; }
        public int CallMissed { get; set; }
    }
}

﻿using CallAPI.Helpers;
using CallAPI.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace CallAPI.Repositories
{
    public interface ICallRepository
    {
        Task<IEnumerable<CallSummaryResponse>> GetCallSummaryReport(string? eventFromTime, string? eventToTime);
        Task<IEnumerable<MissedCallResponse>> GetMissedCallDetails(string callId, string eventFromTime, string eventToTime);
    }
    public class CallRepository : BaseRepository, ICallRepository
    {
        //private DataContext _context;

        public CallRepository(IOptions<DbSettings> dbSettings) : base(dbSettings)
        {
          
        }
        public async Task<IEnumerable<CallSummaryResponse>> GetCallSummaryReport(string? eventFromTime, string? eventToTime)
        {
            var param = new DynamicParameters();
            param.Add("eventStartTime", eventFromTime);
            param.Add("eventEndTime", eventToTime);
            
            return await WithConnection(async conn =>
            {
                var multi = await conn.QueryMultipleAsync("dbo.uspGetSummaryReport", param);
                var result = (await multi.ReadAsync<CallSummaryResponse>()).AsList();

                return result.ToList();
            });
        }

        public async Task<IEnumerable<MissedCallResponse>> GetMissedCallDetails(string callId, string eventFromTime, string eventToTime)
        {
           // using var connection = _context.CreateConnection();
          
            var param = new DynamicParameters();
            param.Add("callId", callId);
            param.Add("eventStartTime", eventFromTime);
            param.Add("eventEndTime", eventToTime);

            return await WithConnection(async conn =>
            {
                var multi = await conn.QueryMultipleAsync("dbo.uspGetMissedCallReport", param);
                var result = (await multi.ReadAsync<MissedCallResponse>()).AsList();

                return result.ToList();
            });
         
        }
    }
}
